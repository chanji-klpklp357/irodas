// Croation
fb.data.strings = [
"hr",
"Zatvori (tipka: Esc)",
"Prethodna (tipka: \u2190\u0090)",
"Slijede\u0107a (tipka: \u2192)",
"Pokreni (tipka: razmaknica)",
"Pauza (tipka: razmaknica)",
"Zumiraj (tipka: Page Up/Down)",
"Slika %1 od %2",
"Strana %1 od %2",
"(%1 od %2)",
"Info...",
"Ispi\u0161i...",
"Otvorite u novom prozoru",
"Pop-up sadr\u017eaj je blokiran od strane ovog preglednika."
];
