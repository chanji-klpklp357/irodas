// Italian
fb.data.strings = [
"it",
"Chiudere (tasto: Esc)",
"Precedente (tasto: \u2190)",
"Seguente (tasto: \u2192)",
"Play (tasto: barra spaziatrice)",
"Pausa (tasto: barra spaziatrice)",
"Ridimensiona (tasto: Page Up/Down)",
"Immagine %1 di %2",
"Pagina %1 di %2",
"(%1 di %2)",
"Info...",
"Stampare...",
"Aprire in una nuova finestra",
"Pop-up contenuto \u00e8 bloccati in questo browser."
];
