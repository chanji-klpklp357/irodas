// Polish
fb.data.strings = [
"pl",
"Zamknij (klawisz: Esc)",
"Wstecz (klawisz: \u2190)",
"Dalej (klawisz: \u2192)",
"Odtwarzaj (klawisz: Spacja)",
"Wstrzymaj (klawisz: Spacja)",
"Przeskaluj (klawisz: Page Up/Down)",
"Zdj\u0119cie %1 z %2",
"Strona %1 z %2",
"(%1 z %2)",
"Opis...",
"Drukuj...",
"Otw\u00f3rz w nowym oknie",
"Popup zawarto\u015b\u0107 jest zablokowana przez tej przegl\u0105darce."
];
