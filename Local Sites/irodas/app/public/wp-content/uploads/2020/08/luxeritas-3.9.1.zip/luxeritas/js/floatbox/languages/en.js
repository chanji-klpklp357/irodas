// English (not used - for reference only)
fb.data.strings = [
"en",
"Close (key: Esc)",
"Prev (key: \u2190)",
"Next (key: \u2192)",
"Play (key: spacebar)",
"Pause (key: spacebar)",
"Resize (key: Page Up/Down)",
"Image %1 of %2",
"Page %1 of %2",
"(%1 of %2)",
"Info...",
"Print...",
"Open in a new window",
"Pop-up content is blocked by this browser."
];
