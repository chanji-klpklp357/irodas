// Dutch
fb.data.strings = [
"nl",
"Sluiten (toets: Esc)",
"Vorige (toets: \u2190)",
"Volgende (toets: \u2192)",
"Afspelen (toets: spatiebalk)",
"Pauze (toets: spatiebalk)",
"Grootte aanpassen (toets: Page Up/Down)",
"Afbeelding %1 van %2",
"Pagina %1 van %2",
"(%1 van %2)",
"Info...",
"Afdrukken...",
"Open in een nieuw venster",
"Popup-inhoud wordt geblokkeerd door deze browser."
];
